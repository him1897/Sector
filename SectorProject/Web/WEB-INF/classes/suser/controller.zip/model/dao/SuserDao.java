package suser.model.dao;

import static common.JDBCTemplate.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import emp.model.vo.Emp;
import master.model.vo.Master;
import suser.model.vo.Suser;

public class SuserDao {

	public Suser loginCheck(Connection conn, String userId, String userPwd) {
		Suser suser = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		/*String query = "select * from suser where user_id = ? and user_pwd = ?";*/
		
		String query = "SELECT *  " + 
				"FROM SUSER " + 
				"JOIN EMP  " + 
				"ON SUSER.USER_ID = EMP.USER_ID " + 
				"WHERE SUSER.USER_ID =  ? AND SUSER.USER_PWD =  ? ";
		
		try {
			conn.setAutoCommit(false);
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPwd);
			
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				suser = new Suser();
				
				suser.setUserId(userId);
				suser.setUserName(rset.getString("USER_NAME"));
				suser.setUserPwd(userPwd);
				suser.setUserComNo(Integer.parseInt(rset.getString("USER_COM_NO")));
				suser.setUserMaster(rset.getString("USER_MASTER"));
				suser.setEmpId(rset.getInt("EMP_ID"));
				
				
				System.out.println(suser.getUserId());
				System.out.println(suser.getUserName());
				System.out.println(suser.getUserPwd());
				System.out.println(suser.getUserComNo());
				System.out.println(suser.getUserMaster());
				System.out.println(suser.getEmpId());
				//System.out.println(suser.getEmpId());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return suser;
	}
	
	
	public ArrayList<Emp> selectList(
			Connection conn, int currentPage, int limit) {
		ArrayList<Emp> list = new ArrayList<Emp>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query = "select * from ("
				+ "select rownum rnum, emp_num, emp_title, "
				+ "emp_writer, emp_content, emp_original_filename, "
				+ "emp_rename_filename, emp_date, emp_readcount, "
				+ "emp_ref, emp_reply_ref, emp_reply_lev, "
				+ "emp_reply_seq from (select * from emp "
				+ "order by emp_ref desc, "
				+ "emp_reply_ref desc nulls first, "
				+ "emp_reply_lev asc, "
				+ "emp_reply_seq asc)) "
				+ "where rnum >= ? and rnum <= ?";
		
		int startRow = (currentPage -1) * limit + 1;
		int endRow = startRow + limit - 1;
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			
			rset = pstmt.executeQuery();
			while(rset.next()) {
				Emp emp = new Emp();
				Suser suser = new Suser();
				
				emp.setEmpId(Integer.parseInt(rset.getNString("EMP_ID")));
				emp.setEmpName("EMP_NAME");
				emp.setDeptId("DEPT_ID");
				emp.setJobId("JOB_ID");
				emp.setEmpPhone("EMP_PHONE");
				emp.setEmpEmail("EMP_EMAIL");
				emp.setEmpAddress("EMP_ADDRESS");
				suser.setIdent("IDENT");
				
				list.add(emp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return list;
	}
	public int getListCount(Connection conn) {
		int listCount = 0;
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select count(*) from emp";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			if(rset.next()) {
				listCount = rset.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(stmt);
		}
		
		return listCount;
	}
	
	
	public Suser selectOne(Connection conn, String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<Suser> selectAll(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertSuser(Connection conn, Suser suser) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteSuser(Connection conn, String userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateSuser(Connection conn, String userId) {
		// TODO Auto-generated method stub
		return 0;
	}

}
