package suser.model.service;


import static common.JDBCTemplate.close;
import static common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import emp.model.vo.Emp;
import suser.model.dao.SuserDao;
import suser.model.vo.Suser;

public class SuserService {

	private SuserDao sdao = new SuserDao();
	
	public SuserService() {}
	
	public Suser loginCheck(String userId, String userPwd) {
		
		Connection conn = getConnection();
		Suser loginMember = sdao.loginCheck(conn, userId, userPwd);
		close(conn);
		return loginMember;
	}
	
	
	/*public Suser selectOne(String userId) {
		
		Connection conn = getConnection();
		Suser suser = sdao.selectOne(conn, userId);
		
		return suser;
		
	}*/
	
	//�Խñ� ��ü ��� ���� ��ȸ ����
		public int getListCount() {
			Connection conn = getConnection();
			int listCount = sdao.getListCount(conn);
			close(conn);
			return listCount;
		}

		public ArrayList<Emp> selectList(
			int currentPage, int limit){
			Connection conn = getConnection();
			ArrayList<Emp> list = sdao.selectList(conn, currentPage, limit);
			close(conn);
			return list;
		}
	
	public ArrayList<Suser> selectAll(){
		
		Connection conn = getConnection();
		ArrayList<Suser>list = sdao.selectAll(conn);
		
		return list;
		
	}
	
	public int insertSuser(Suser suser) {
		
		Connection conn = getConnection();
		int result = sdao.insertSuser(conn, suser);
		
		return result;
	}
	
	public int deleteSuser(String userId) {
		
		Connection conn = getConnection();
		int result = sdao.deleteSuser(conn, userId);
		
		return result;
	}
	
	public int updateSuser(String userId) {
		
		Connection conn = getConnection();
		int result = sdao.updateSuser(conn, userId);
		
		return result;
	}
	
}
